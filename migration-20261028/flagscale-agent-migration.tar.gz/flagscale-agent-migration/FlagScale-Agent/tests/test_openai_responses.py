"""Exercise protocol selection and tool round trips through the real OpenAI SDK."""

import json
from copy import deepcopy
from types import SimpleNamespace

import httpx
import pytest
from openai import BadRequestError, OpenAI
from typer.testing import CliRunner

from flagscale_agent.cli import app
from flagscale_agent.react.agent import WorkerAgent
from flagscale_agent.react.config import AgentConfig
from flagscale_agent.react.history import HistoryManager
from flagscale_agent.react.providers import get_provider
from flagscale_agent.react.providers.openai_provider import OpenAIProvider


TOOLS = [{"type": "function", "function": {
    "name": "shell", "description": "Run a command",
    "parameters": {"type": "object", "properties": {"command": {"type": "string"}}},
}}]
REASONING = {"type": "reasoning", "id": "rs_1", "summary": [],
             "encrypted_content": "opaque-reasoning"}
CALL = {"type": "function_call", "id": "fc_1", "call_id": "call_1",
        "name": "shell", "arguments": '{"command":"nvidia-smi"}'}


def response(output=None, status="completed"):
    return {"id": "resp_1", "object": "response", "created_at": 1,
            "model": "test-model", "status": status, "error": None,
            "output": output or [], "usage": {
                "input_tokens": 100, "output_tokens": 20, "total_tokens": 120,
                "input_tokens_details": {"cached_tokens": 40},
                "output_tokens_details": {"reasoning_tokens": 5},
            }}


def sse(events):
    return httpx.Response(200, headers={"content-type": "text/event-stream"},
                          content="".join(f"event: {e['type']}\ndata: {json.dumps(e)}\n\n"
                                          for e in events))


@pytest.fixture
def make_provider():
    clients = []

    def make(handler, api_type="auto"):
        provider = OpenAIProvider("test-model", "test-key", api_type=api_type)
        provider._client.close()
        provider._client = OpenAI(api_key="test-key", base_url="https://relay.example/v1",
                                  max_retries=0,
                                  http_client=httpx.Client(transport=httpx.MockTransport(handler)))
        clients.append(provider._client)
        return provider

    yield make
    for client in clients:
        client.close()


@pytest.mark.parametrize("stream", [False, True])
@pytest.mark.parametrize("message", [
    "This model does not support chat completions; use responses",
    "模型不支持 chat completions 协议",
])
def test_auto_switches_endpoint_and_keeps_selected_protocol(make_provider, stream, message):
    requests = []

    def handler(req):
        data = json.loads(req.content)
        requests.append((req.url.path, data))
        if req.url.path.endswith("chat/completions"):
            assert data["tools"] == TOOLS
            return httpx.Response(400, json={"error": {"message": message}})
        assert req.url.path == "/v1/responses"
        assert data["tools"][0]["name"] == "shell"
        assert data["tools"][0]["strict"] is False
        assert "function" not in data["tools"][0]
        assert data["input"] == [{"role": "user", "content": "Hi"}]
        assert data["max_output_tokens"] == 8192
        assert not {"messages", "max_tokens", "stream_options"} & data.keys()
        if stream:
            return sse([{"type": "response.output_text.delta", "delta": "OK"},
                        {"type": "response.completed", "response": response()}])
        return httpx.Response(200, json=response([{
            "type": "message", "id": "msg_1", "role": "assistant", "status": "completed",
            "content": [{"type": "output_text", "text": "OK", "annotations": []}],
        }]))

    provider = make_provider(handler)
    for _ in range(2):
        messages = [{"role": "user", "content": "Hi"}]
        if stream:
            events = list(provider.chat_stream(messages, TOOLS))
            assert events[0] == {"type": "text", "content": "OK"}
            assert events[-1] == {"type": "done"}
        else:
            assert provider.chat(messages, TOOLS)["content"] == "OK"
    assert [path for path, _ in requests] == [
        "/v1/chat/completions", "/v1/responses", "/v1/responses"]


@pytest.mark.parametrize("stream", [False, True])
@pytest.mark.parametrize("api_type", ["responses", "auto"])
def test_merged_user_and_guard_messages_use_responses_text_blocks(make_provider, stream, api_type):
    requests = []

    def handler(req):
        requests.append(req.url.path)
        if req.url.path.endswith("chat/completions"):
            return httpx.Response(400, json={"error": {
                "message": "This model does not support chat completions; use responses"}})
        assert req.url.path == "/v1/responses"
        assert json.loads(req.content)["input"] == [{"role": "user", "content": [
            {"type": "input_text", "text": "Check GPU"},
            {"type": "input_text", "text": "[GUARD ADVISORY] Inspect the environment first"},
        ]}]
        if stream:
            return sse([{"type": "response.completed", "response": response()}])
        return httpx.Response(200, json=response())

    history = HistoryManager()
    history.append({"role": "user", "content": "Check GPU"})
    history.append({"role": "user", "content": "[GUARD ADVISORY] Inspect the environment first"})
    messages = history.get_messages()
    original = deepcopy(messages)
    assert all(block["type"] == "text" for block in messages[0]["content"])
    provider = make_provider(handler, api_type)
    if stream:
        assert list(provider.chat_stream(messages, []))[-1] == {"type": "done"}
    else:
        assert provider.chat(messages, [])["content"] is None
    assert messages == original
    assert requests == (["/v1/chat/completions"] if api_type == "auto" else []) + ["/v1/responses"]


def test_responses_preserves_existing_typed_blocks_and_source_history(make_provider):
    provider = make_provider(lambda req: httpx.Response(200, json=response()), "responses")
    blocks = [
        {"type": "text", "text": "Legacy text"},
        {"type": "input_text", "text": "Already converted"},
        {"type": "input_image", "image_url": "https://example.test/image.png", "detail": "auto"},
    ]
    messages = [{"role": "user", "content": blocks}]
    original = deepcopy(messages)
    assert provider._build_responses_kwargs(messages, [])["input"][0]["content"] == [
        {"type": "input_text", "text": "Legacy text"}, *blocks[1:]]
    assert messages == original
    assert provider._build_kwargs(messages, [])["messages"][0]["content"] == blocks


@pytest.mark.parametrize("api_type,message", [
    ("auto", "Invalid tool schema"),
    ("auto", "Unsupported tools in chat completions"),
    ("chat_completions", "This model does not support chat completions"),
])
def test_other_400s_and_explicit_chat_do_not_fallback(make_provider, api_type, message):
    paths = []

    def handler(req):
        paths.append(req.url.path)
        return httpx.Response(400, json={"error": {"message": message}})

    with pytest.raises(BadRequestError):
        list(make_provider(handler, api_type).chat_stream([], []))
    assert paths == ["/v1/chat/completions"]


@pytest.mark.parametrize("send_deltas", [False, True])
def test_parallel_calls_and_final_arguments_are_associated_with_call_ids(make_provider, send_deltas):
    calls = [CALL, {**CALL, "id": "fc_2", "call_id": "call_2", "arguments": '{"command":"pwd"}'}]
    events = [{"type": "response.output_item.added", "output_index": i,
               "item": {**call, "arguments": ""}} for i, call in enumerate(calls)]
    if send_deltas:
        events.extend({"type": "response.function_call_arguments.delta", "item_id": call["id"],
                       "output_index": i, "delta": call["arguments"]}
                      for i, call in reversed(list(enumerate(calls))))
    events.extend({"type": "response.output_item.done", "output_index": i, "item": call}
                  for i, call in enumerate(calls))
    events.append({"type": "response.completed", "response": response(calls)})
    agent = WorkerAgent.__new__(WorkerAgent)
    agent.config = SimpleNamespace(thinking_budget=0)
    agent.provider = make_provider(lambda req: sse(events), "responses")
    result, _ = agent._call_llm_stream([], TOOLS)
    assert result["tool_calls"] == [
        {"id": call["call_id"], "name": call["name"], "arguments": json.loads(call["arguments"])}
        for call in calls]


@pytest.mark.parametrize("stream", [False, True])
def test_tool_round_trip_preserves_call_id_reasoning_and_usage(make_provider, stream):
    requests = []

    def handler(req):
        data = json.loads(req.content)
        requests.append(data)
        assert req.url.path == "/v1/responses"
        if len(requests) == 2:
            assert data["input"][2] == REASONING
            function_call = data["input"][3]
            assert {k: function_call[k] for k in ("type", "call_id", "name")} == {
                k: CALL[k] for k in ("type", "call_id", "name")}
            assert json.loads(function_call["arguments"]) == json.loads(CALL["arguments"])
            assert data["input"][4] == {"type": "function_call_output",
                                        "call_id": "call_1", "output": "GPU ready"}
        if not stream:
            return httpx.Response(200, json=response([REASONING, CALL]))
        return sse([
            {"type": "response.output_item.added", "output_index": 1,
             "item": {**CALL, "arguments": ""}},
            {"type": "response.function_call_arguments.delta", "item_id": "fc_1",
             "output_index": 1, "delta": '{"command":'},
            {"type": "response.function_call_arguments.delta", "item_id": "fc_1",
             "output_index": 1, "delta": '"nvidia-smi"}'},
            {"type": "response.output_item.done", "output_index": 0, "item": REASONING},
            {"type": "response.output_item.done", "output_index": 1, "item": CALL},
            {"type": "response.completed", "response": response([REASONING, CALL])},
        ])

    provider = make_provider(handler, "responses")
    history = HistoryManager()
    history.set_system_prompt("You are an assistant.")
    history.append({"role": "user", "content": "Check GPU"})
    agent = WorkerAgent.__new__(WorkerAgent)
    agent.config = SimpleNamespace(thinking_budget=0)
    agent.provider = provider
    if stream:
        result, usage = agent._call_llm_stream(history.get_messages(), TOOLS)
        assert usage["input_tokens"] == 100
        assert usage["cache_read_input_tokens"] == 40
    else:
        result = provider.chat(history.get_messages(), TOOLS)
    assert result["tool_calls"] == [{"id": "call_1", "name": "shell",
                                     "arguments": {"command": "nvidia-smi"}}]
    assert result["_responses_reasoning"] == [REASONING]
    history.append(provider.format_assistant_message(result))
    history.append(provider.format_tool_result("call_1", "GPU ready"))
    if stream:
        agent._call_llm_stream(history.get_messages(), TOOLS)
    else:
        provider.chat(history.get_messages(), TOOLS)
    assert len(requests) == 2


@pytest.mark.parametrize("kind", ["response.failed", "error", "disconnect", "response.incomplete"])
def test_stream_failures_are_not_silently_reported_as_success(make_provider, kind):
    events = []
    if kind == "error":
        events = [{"type": kind, "message": "upstream rejected request"}]
    elif kind != "disconnect":
        events = [{"type": kind, "response": response(status=kind.split(".")[1])}]
    provider = make_provider(lambda req: sse(events), "responses")
    if kind == "response.incomplete":
        agent = WorkerAgent.__new__(WorkerAgent)
        agent.config = SimpleNamespace(thinking_budget=0)
        agent.provider = provider
        result, _ = agent._call_llm_stream([], [])
        assert result["truncated"] is True
    else:
        with pytest.raises(RuntimeError):
            list(provider.chat_stream([], []))


def test_cli_yaml_and_factory_select_responses(tmp_path, monkeypatch):
    import sys
    from unittest.mock import MagicMock

    path = tmp_path / "agent.yaml"
    path.write_text("provider: openai\nmodel: test-model\napi_key: test-key\nopenai_api: responses\n")
    monkeypatch.setenv("FLAGSCALE_HOME", str(tmp_path))
    worker = MagicMock()
    monkeypatch.setitem(sys.modules, "flagscale_agent.react.agent", SimpleNamespace(WorkerAgent=worker))
    result = CliRunner().invoke(app, ["--config", str(path), "hello"])
    assert result.exit_code == 0, result.output
    assert worker.call_args.args[0].openai_api == "responses"
    result = CliRunner().invoke(app, ["--config", str(path), "--openai-api", "chat_completions", "hello"])
    assert result.exit_code == 0, result.output
    assert worker.call_args.args[0].openai_api == "chat_completions"
    provider = get_provider("openai", "test", "key", openai_api="responses")
    assert provider._api_type == "responses"
    provider._client.close()
    with pytest.raises(ValueError, match="openai_api"):
        AgentConfig(openai_api="invalid")
