# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tests for retry_with_backoff."""

import pytest

from flagscale_agent.react.retry import (
    retry_with_backoff, _is_retryable_exception, _is_context_limit_error,
)


class FakeAPIError(Exception):
    def __init__(self, status_code):
        self.status_code = status_code
        super().__init__(f"API error {status_code}")


class ConnectionError(Exception):
    pass


class APIConnectionError(Exception):
    pass


class APITimeoutError(Exception):
    pass


class TestRetryWithBackoff:
    def test_success_no_retry(self):
        calls = []
        def fn():
            calls.append(1)
            return "ok"
        result = retry_with_backoff(fn, max_retries=3, base_delay=0.01)
        assert result == "ok"
        assert len(calls) == 1

    def test_retry_on_429(self):
        attempts = []
        def fn():
            attempts.append(1)
            if len(attempts) < 3:
                raise FakeAPIError(429)
            return "ok"
        result = retry_with_backoff(fn, max_retries=3, base_delay=0.01)
        assert result == "ok"
        assert len(attempts) == 3

    def test_no_retry_on_400(self):
        def fn():
            raise FakeAPIError(400)
        with pytest.raises(FakeAPIError):
            retry_with_backoff(fn, max_retries=3, base_delay=0.01)

    def test_exhausted_retries(self):
        def fn():
            raise FakeAPIError(500)
        with pytest.raises(FakeAPIError):
            retry_with_backoff(fn, max_retries=2, base_delay=0.01)

    def test_non_api_error_no_retry(self):
        def fn():
            raise ValueError("bad input")
        with pytest.raises(ValueError):
            retry_with_backoff(fn, max_retries=3, base_delay=0.01)

    def test_retry_on_connection_error(self):
        attempts = []
        def fn():
            attempts.append(1)
            if len(attempts) < 3:
                raise ConnectionError("connection reset")
            return "ok"
        result = retry_with_backoff(fn, max_retries=3, base_delay=0.01)
        assert result == "ok"
        assert len(attempts) == 3

    def test_retry_on_api_connection_error(self):
        attempts = []
        def fn():
            attempts.append(1)
            if len(attempts) < 2:
                raise APIConnectionError("failed to connect")
            return "ok"
        result = retry_with_backoff(fn, max_retries=3, base_delay=0.01)
        assert result == "ok"
        assert len(attempts) == 2

    def test_retry_on_api_timeout_error(self):
        attempts = []
        def fn():
            attempts.append(1)
            if len(attempts) < 2:
                raise APITimeoutError("timed out")
            return "ok"
        result = retry_with_backoff(fn, max_retries=3, base_delay=0.01)
        assert result == "ok"
        assert len(attempts) == 2

    def test_connection_error_exhausted(self):
        def fn():
            raise ConnectionError("always fails")
        with pytest.raises(ConnectionError):
            retry_with_backoff(fn, max_retries=2, base_delay=0.01)


class TestIsRetryableException:
    def test_connection_error(self):
        assert _is_retryable_exception(ConnectionError("test"))

    def test_api_connection_error(self):
        assert _is_retryable_exception(APIConnectionError("test"))

    def test_api_timeout_error(self):
        assert _is_retryable_exception(APITimeoutError("test"))

    def test_value_error_not_retryable(self):
        assert not _is_retryable_exception(ValueError("test"))

    def test_generic_exception_not_retryable(self):
        assert not _is_retryable_exception(Exception("test"))


class TestIsContextLimitError:
    def test_context_length(self):
        assert _is_context_limit_error(Exception("context length exceeded"))

    def test_prompt_too_long(self):
        assert _is_context_limit_error(Exception("prompt is too long for this model"))

    def test_request_too_large(self):
        assert _is_context_limit_error(Exception("Request too large"))

    def test_too_many_tokens(self):
        assert _is_context_limit_error(Exception("too many tokens in the input"))

    def test_unrelated_400(self):
        assert not _is_context_limit_error(Exception("invalid parameter: temperature"))

    def test_empty_message(self):
        assert not _is_context_limit_error(Exception(""))
