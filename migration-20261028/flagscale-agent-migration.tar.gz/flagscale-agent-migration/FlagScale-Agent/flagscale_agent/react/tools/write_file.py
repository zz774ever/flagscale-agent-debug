# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Write file tool."""

import os

from flagscale_agent.react.tools.base import Tool
from flagscale_agent.react.tools.read_file import get_file_cache

# -- Paths that should never be written by the agent --
_PROTECTED_PATHS = frozenset({
    os.path.expanduser("~/.bashrc"),
    os.path.expanduser("~/.profile"),
    os.path.expanduser("~/.bash_profile"),
    os.path.expanduser("~/.zshrc"),
    os.path.expanduser("~/.ssh/authorized_keys"),
})


def _is_protected_path(path: str) -> bool:
    """Check if path is protected from agent writes."""
    resolved = os.path.abspath(os.path.realpath(path))
    if resolved in _PROTECTED_PATHS:
        return True
    if resolved.startswith("/etc/") and not resolved.startswith("/etc/apt/"):
        return True
    if resolved.startswith("/boot/"):
        return True
    return False


class WriteFileTool(Tool):
    name = "write_file"
    description = (
        "Create or overwrite a file at the given path with the provided content. "
        "IMPORTANT: Each call's content parameter MUST be under 3000 characters. "
        "If content exceeds 3000 chars, you MUST split into multiple calls: "
        "first call with mode='write', subsequent calls with mode='append'. "
        "Failing to split will cause output truncation and incomplete file writes. "
        "SPLITTING STRATEGY for large documents: Plan your sections BEFORE writing. "
        "Write section 1 (≤3000 chars) with mode='write', then each subsequent section "
        "with mode='append'. NEVER attempt to write an entire large document in one call — "
        "if your content has multiple sections/chapters, split at natural boundaries (## headers). "
        "A truncated write_file call loses ALL content including the path parameter, wasting the entire turn."
    )
    parameters = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "The file path to write.",
            },
            "content": {
                "type": "string",
                "description": "The content to write to the file.",
            },
            "mode": {
                "type": "string",
                "enum": ["write", "append"],
                "description": "Write mode: 'write' (default) overwrites the file, 'append' adds to the end.",
            },
        },
        "required": ["path", "content"],
    }

    def execute(self, **kwargs) -> str:
        path = kwargs.get("path", "")
        content = kwargs.get("content", "")
        mode = kwargs.get("mode", "write")

        if not path:
            return "ERROR: 'path' parameter is required but was empty or missing (possible output truncation)."
        if not content:
            return "ERROR: 'content' parameter is required but was empty or missing (possible output truncation)."

        if _is_protected_path(path):
            return f"ERROR: Cannot write to protected system path: {path}"

        file_mode = "a" if mode == "append" else "w"
        try:
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            with open(path, file_mode, encoding="utf-8") as f:
                f.write(content)
            get_file_cache().invalidate(os.path.abspath(path))
            get_file_cache().invalidate(path)
            action = "Appended" if mode == "append" else "Wrote"
            total = os.path.getsize(os.path.abspath(path))
            return f"{action} {len(content)} chars to {path} (total file size: {total} bytes)"
        except Exception as e:
            return f"ERROR: {e}"
