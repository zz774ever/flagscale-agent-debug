# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""OpenAI provider implementation."""

import json

from typing import Any, Dict, Iterator, List

from openai import BadRequestError, OpenAI

from flagscale_agent.react.providers.base import LLMProvider



class OpenAIProvider(LLMProvider):
    def __init__(self, model: str, api_key: str, base_url: str = None, max_tokens: int = 8192, api_type: str = "auto"):
        if api_type not in ("auto", "chat_completions", "responses"):
            raise ValueError("openai_api must be auto, chat_completions, or responses")
        self._model = model
        self._max_tokens = max_tokens
        self._base_url = base_url
        self._api_type = api_type
        kwargs = {"api_key": api_key, "timeout": 120.0}
        if base_url:
            kwargs["base_url"] = base_url
        self._client = OpenAI(**kwargs)

    def _build_kwargs(self, messages, tools, stream=False):
        """Build API call kwargs, with prompt caching support."""
        kwargs = {
            "model": self._model,
            "messages": [{k: v for k, v in message.items() if not k.startswith("_")}
                         for message in messages],
            "max_tokens": self._max_tokens,
        }
        if stream:
            kwargs["stream"] = True
            kwargs["stream_options"] = {"include_usage": True}
        if tools:
            kwargs["tools"] = tools
        return kwargs

    def _build_responses_kwargs(self, messages, tools, stream=False):
        """Translate the agent's history into stateless Responses input items."""
        items = []
        for message in messages:
            role = message["role"]
            if role == "tool":
                items.append({"type": "function_call_output",
                              "call_id": message["tool_call_id"],
                              "output": message.get("content") or ""})
                continue
            items.extend(message.get("_responses_reasoning", []))
            content = message.get("content")
            if content:
                if isinstance(content, list):
                    # History merges user/guard messages into legacy text blocks.
                    # Convert at the API boundary without modifying stored history.
                    content = [
                        {**block, "type": "input_text"}
                        if isinstance(block, dict) and block.get("type") == "text" else block
                        for block in content
                    ]
                items.append({"role": role, "content": content})
            for call in message.get("tool_calls", []):
                items.append({"type": "function_call", "call_id": call["id"],
                              "name": call["function"]["name"],
                              "arguments": call["function"]["arguments"]})
        kwargs = {
            "model": self._model,
            "input": items,
            "max_output_tokens": self._max_tokens,
            "store": False,
            "include": ["reasoning.encrypted_content"],
        }
        if stream:
            kwargs["stream"] = True
        if tools:
            # Responses function definitions are flat; Chat Completions are nested.
            kwargs["tools"] = [
                {"type": "function", **tool["function"],
                 "strict": tool["function"].get("strict", False)}
                if tool.get("type") == "function" and "function" in tool else tool
                for tool in tools
            ]
        return kwargs

    def _create(self, messages, tools, stream=False):
        if self._api_type != "responses":
            try:
                return self._client.chat.completions.create(
                    **self._build_kwargs(messages, tools, stream=stream)
                )
            except BadRequestError as exc:
                # Only a protocol rejection may select a different endpoint.
                # Authentication, malformed tools, etc. must retain their errors.
                error = str(exc).lower().replace("_", " ").replace("/", " ")
                mentions_chat = "chat" in error and "completion" in error
                unsupported = any(term in error for term in
                                  ("not support", "doesn't support", "unsupported", "不支持", "only support"))
                protocol_rejection = any(term in error for term in
                                         ("model", "模型", "responses", "protocol", "协议", "endpoint"))
                if self._api_type != "auto" or not (mentions_chat and unsupported and protocol_rejection):
                    raise
                self._api_type = "responses"
        return self._client.responses.create(
            **self._build_responses_kwargs(messages, tools, stream=stream)
        )

    @staticmethod
    def _parse_responses(response):
        if response.status == "failed" or response.error:
            raise RuntimeError(f"Responses API failed: {response.error}")
        content, tool_calls, reasoning = [], [], []
        for item in response.output:
            if item.type == "message":
                for part in item.content:
                    if part.type == "output_text":
                        content.append(part.text)
                    elif part.type == "refusal":
                        content.append(part.refusal)
            elif item.type == "function_call":
                try:
                    arguments = json.loads(item.arguments)
                except (json.JSONDecodeError, TypeError):
                    arguments = {}
                tool_calls.append({"id": item.call_id, "name": item.name,
                                   "arguments": arguments})
            elif item.type == "reasoning":
                reasoning.append(item.model_dump(exclude_none=True))
        return {"content": "".join(content) or None, "tool_calls": tool_calls or None,
                "_responses_reasoning": reasoning,
                "truncated": response.status == "incomplete"}

    def chat(self, messages: List[Dict[str, Any]], tools: List[dict]) -> Dict[str, Any]:
        try:
            response = self._create(messages, tools)
            if self._api_type == "responses":
                return self._parse_responses(response)
        except Exception as e:
            return {"content": f"[PROVIDER_ERROR] {type(e).__name__}: {e}", "tool_calls": None}

        choice = response.choices[0]
        message = choice.message

        tool_calls = None
        if message.tool_calls:
            tool_calls = []
            for tc in message.tool_calls:
                try:
                    arguments = json.loads(tc.function.arguments)
                except (json.JSONDecodeError, TypeError):
                    arguments = {}
                tool_calls.append({"id": tc.id, "name": tc.function.name, "arguments": arguments})

        return {"content": message.content, "tool_calls": tool_calls}

    def chat_stream(self, messages: List[Dict[str, Any]], tools: List[dict]) -> Iterator[Dict[str, Any]]:
        stream = self._create(messages, tools, stream=True)
        if self._api_type == "responses":
            yield from self._responses_stream(stream)
            return
        seen_tool_ids = set()
        had_reasoning = False
        for chunk in stream:
            if chunk.usage:
                usage_data = {
                    "type": "usage",
                    "input_tokens": chunk.usage.prompt_tokens,
                    "output_tokens": chunk.usage.completion_tokens,
                }
                # Include cache stats when available (OpenAI prompt caching)
                ptd = getattr(chunk.usage, "prompt_tokens_details", None)
                if ptd:
                    cached = getattr(ptd, "cached_tokens", None)
                    if cached is None and isinstance(ptd, dict):
                        cached = ptd.get("cached_tokens")
                    if cached:
                        usage_data["cache_read_input_tokens"] = cached
                    cache_write = getattr(ptd, "cache_write_tokens", None)
                    if cache_write is None and isinstance(ptd, dict):
                        cache_write = ptd.get("cache_write_tokens")
                    if cache_write:
                        usage_data["cache_creation_input_tokens"] = cache_write
                yield usage_data
            delta = chunk.choices[0].delta if chunk.choices else None
            if delta is None:
                continue
            if delta.content:
                yield {"type": "text", "content": delta.content}
            # Detect reasoning tokens: GLM uses "reasoning" field in raw SSE,
            # some providers use "reasoning_content". Check both attribute and
            # model_extra (Pydantic v2 strips unknown fields from typed models).
            rc = getattr(delta, "reasoning_content", None)
            if not rc:
                rc = (delta.model_extra or {}).get("reasoning_content") if hasattr(delta, "model_extra") else None
            if not rc:
                rc = (delta.model_extra or {}).get("reasoning") if hasattr(delta, "model_extra") else None
            if rc:
                had_reasoning = True
                yield {"type": "thinking", "content": rc}
            if delta.tool_calls:
                for tc in delta.tool_calls:
                    if tc.function and tc.function.name:
                        tc_id = tc.id or ""
                        if tc_id and tc_id not in seen_tool_ids:
                            seen_tool_ids.add(tc_id)
                            yield {"type": "tool_start", "id": tc.id, "name": tc.function.name}
                    if tc.function and tc.function.arguments:
                        yield {"type": "tool_delta", "id": tc.id or "", "arguments_delta": tc.function.arguments}
        if had_reasoning:
            yield {"type": "reasoning_only"}
        yield {"type": "done"}

    def _responses_stream(self, stream):
        calls = {}
        reasoning_ids = set()
        had_reasoning = False
        finished = False
        try:
            for event in stream:
                kind = event.type
                if kind in ("response.output_text.delta", "response.refusal.delta"):
                    yield {"type": "text", "content": event.delta}
                elif kind in ("response.reasoning_summary_text.delta", "response.reasoning_text.delta"):
                    had_reasoning = True
                    yield {"type": "thinking", "content": event.delta}
                elif kind == "response.output_item.added" and event.item.type == "function_call":
                    item = event.item
                    calls[item.id] = {"id": item.call_id, "arguments": item.arguments or ""}
                    yield {"type": "tool_start", "id": item.call_id, "name": item.name}
                    if item.arguments:
                        yield {"type": "tool_delta", "id": item.call_id,
                               "arguments_delta": item.arguments}
                elif kind == "response.function_call_arguments.delta":
                    call = calls[event.item_id]
                    call["arguments"] += event.delta
                    yield {"type": "tool_delta", "id": call["id"],
                           "arguments_delta": event.delta}
                elif kind == "response.output_item.done":
                    item = event.item
                    if item.type == "reasoning":
                        reasoning_ids.add(item.id)
                        yield {"type": "response_reasoning", "item": item.model_dump(exclude_none=True)}
                    elif item.type == "function_call" and item.id not in calls:
                        calls[item.id] = {"id": item.call_id, "arguments": item.arguments}
                        yield {"type": "tool_start", "id": item.call_id, "name": item.name}
                        yield {"type": "tool_delta", "id": item.call_id, "arguments_delta": item.arguments}
                    elif item.type == "function_call":
                        call = calls[item.id]
                        # Some gateways only supply the full arguments at item.done.
                        if item.arguments.startswith(call["arguments"]):
                            remainder = item.arguments[len(call["arguments"]):]
                            if remainder:
                                yield {"type": "tool_delta", "id": call["id"],
                                       "arguments_delta": remainder}
                            call["arguments"] = item.arguments
                elif kind in ("response.completed", "response.incomplete"):
                    finished = True
                    response = event.response
                    for item in response.output:
                        if item.type == "reasoning" and item.id not in reasoning_ids:
                            reasoning_ids.add(item.id)
                            yield {"type": "response_reasoning", "item": item.model_dump(exclude_none=True)}
                    usage = response.usage
                    if usage:
                        data = {"type": "usage", "input_tokens": usage.input_tokens,
                                "output_tokens": usage.output_tokens}
                        details = usage.input_tokens_details
                        if details and details.cached_tokens:
                            data["cache_read_input_tokens"] = details.cached_tokens
                        yield data
                    if kind == "response.incomplete":
                        yield {"type": "truncated"}
                elif kind == "response.failed":
                    raise RuntimeError(f"Responses API failed: {event.response.error}")
                elif kind == "error":
                    raise RuntimeError(f"Responses API error: {event.message}")
            if not finished:
                raise RuntimeError("Responses stream ended without a completion event")
            if had_reasoning:
                yield {"type": "reasoning_only"}
            yield {"type": "done"}
        finally:
            stream.close()

    def format_assistant_message(self, response: Dict[str, Any]) -> Dict[str, Any]:
        msg = {"role": "assistant"}
        if response.get("_responses_reasoning"):
            msg["_responses_reasoning"] = response["_responses_reasoning"]
        if response.get("thinking"):
            msg["thinking"] = response["thinking"]
        if response["content"]:
            msg["content"] = response["content"]
        if response["tool_calls"]:
            msg["tool_calls"] = [
                {
                    "id": tc["id"],
                    "type": "function",
                    "function": {"name": tc["name"], "arguments": json.dumps(tc["arguments"])},
                }
                for tc in response["tool_calls"]
            ]
        return msg

    def format_tool_result(self, tool_call_id: str, content: str) -> Dict[str, Any]:
        return {"role": "tool", "tool_call_id": tool_call_id, "content": content}
