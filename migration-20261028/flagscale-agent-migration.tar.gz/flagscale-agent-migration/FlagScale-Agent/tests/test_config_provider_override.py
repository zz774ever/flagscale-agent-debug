"""Test provider override in AgentConfig.auto_load()"""
import os
import pytest
from flagscale_agent.react.config import AgentConfig


def test_provider_override_openai(monkeypatch, tmp_path):
    """Test that provider='openai' override correctly switches to OpenAI config."""
    # Set up environment
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-openai-key")
    monkeypatch.setenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
    monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "sk-test-anthropic-key")
    monkeypatch.delenv("FLAGSCALE_AGENT_CONFIG", raising=False)
    
    # Mock get_config_path to return non-existent path
    import flagscale_agent.react.paths as paths_module
    monkeypatch.setattr(
        paths_module, 
        "get_config_path", 
        lambda: str(tmp_path / "nonexistent.yaml")
    )
    
    # Test default (should be anthropic)
    cfg_default = AgentConfig.auto_load()
    assert cfg_default.provider == "anthropic"
    assert cfg_default.api_key == "sk-test-anthropic-key"
    
    # Test with provider='openai' override
    cfg_openai = AgentConfig.auto_load(provider="openai")
    assert cfg_openai.provider == "openai"
    assert cfg_openai.api_key == "sk-test-openai-key"
    assert cfg_openai.base_url == "https://api.openai.com/v1"
    assert cfg_openai.model == "gpt-4o"  # Default OpenAI model


def test_provider_override_with_model(monkeypatch, tmp_path):
    """Test that model override also works with provider override."""
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-key")
    monkeypatch.delenv("FLAGSCALE_AGENT_CONFIG", raising=False)
    
    import flagscale_agent.react.paths as paths_module
    monkeypatch.setattr(
        paths_module,
        "get_config_path",
        lambda: str(tmp_path / "nonexistent.yaml")
    )
    
    cfg = AgentConfig.auto_load(provider="openai", model="gpt-4o-mini")
    assert cfg.provider == "openai"
    assert cfg.model == "gpt-4o-mini"
    assert cfg.api_key == "sk-test-key"


def test_provider_override_without_api_key(monkeypatch, tmp_path):
    """Test that provider override without API key sets api_key to None."""
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("FLAGSCALE_AGENT_CONFIG", raising=False)
    
    import flagscale_agent.react.paths as paths_module
    monkeypatch.setattr(
        paths_module,
        "get_config_path",
        lambda: str(tmp_path / "nonexistent.yaml")
    )
    
    cfg = AgentConfig.auto_load(provider="openai")
    assert cfg.provider == "openai"
    assert cfg.api_key is None


@pytest.fixture
def openai_config(monkeypatch, tmp_path):
    path = tmp_path / "agent.yaml"
    path.write_text(
        "provider: openai\nmodel: gpt-4o-mini\napi_key: yaml-key\n"
        "base_url: https://relay.example.com/v1\nmax_iterations: 7\n"
    )
    monkeypatch.setenv("FLAGSCALE_AGENT_CONFIG", str(path))
    monkeypatch.setenv("FLAGSCALE_HOME", str(tmp_path))
    monkeypatch.setenv("OPENAI_API_KEY", "env-openai-key")
    monkeypatch.setenv("OPENAI_BASE_URL", "https://env.example.com/v1")
    monkeypatch.setenv("OPENAI_DEFAULT_MODEL", "gpt-4o")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "env-anthropic-key")
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "https://anthropic.example.com")
    monkeypatch.setenv("ANTHROPIC_MODEL", "claude-test")
    monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)
    return path


@pytest.mark.parametrize("provider", [None, "openai"])
def test_yaml_values_survive_same_provider_override(openai_config, provider):
    config = AgentConfig.auto_load(provider=provider, model=None, base_url=None)
    assert config.provider == "openai"
    assert config.model == "gpt-4o-mini"
    assert config.api_key == "yaml-key"
    assert config.base_url == "https://relay.example.com/v1"
    assert config.max_iterations == 7
    assert config.max_context_tokens == 128000


@pytest.mark.parametrize("explicit_context", [0, 32000])
def test_model_override_resolves_context_after_merge(openai_config, explicit_context):
    config = AgentConfig.auto_load(model="gpt-4", max_context_tokens=explicit_context)
    assert config.model == "gpt-4"
    assert config.api_key == "yaml-key"
    assert config.max_context_tokens == (explicit_context or 8192)


def test_switching_provider_resolves_new_credentials(openai_config):
    config = AgentConfig.auto_load(provider="anthropic")
    assert config.provider == "anthropic"
    assert config.model == "claude-test"
    assert config.api_key == "env-anthropic-key"
    assert config.base_url == "https://anthropic.example.com"
    assert config.max_iterations == 7


def test_explicit_overrides_survive_provider_switch(openai_config):
    config = AgentConfig.from_yaml(
        str(openai_config), provider="anthropic", model="claude-explicit",
        api_key="explicit-key", base_url="https://explicit.example.com",
    )
    assert config.provider == "anthropic"
    assert config.model == "claude-explicit"
    assert config.api_key == "explicit-key"
    assert config.base_url == "https://explicit.example.com"


@pytest.mark.parametrize("explicit_path", [False, True])
@pytest.mark.parametrize("provider_args", [[], ["--provider", "openai"]])
def test_cli_preserves_yaml_config(openai_config, monkeypatch, explicit_path, provider_args):
    import sys
    from types import SimpleNamespace
    from unittest.mock import MagicMock

    from typer.testing import CliRunner

    from flagscale_agent.cli import app

    worker = MagicMock()
    monkeypatch.setitem(sys.modules, "flagscale_agent.react.agent", SimpleNamespace(WorkerAgent=worker))
    args = ["--config", str(openai_config)] if explicit_path else []
    result = CliRunner().invoke(app, args + provider_args + ["hello"])
    assert result.exit_code == 0, result.output
    config = worker.call_args.args[0]
    assert config.provider == "openai"
    assert config.model == "gpt-4o-mini"
    assert config.api_key == "yaml-key"
    assert config.base_url == "https://relay.example.com/v1"
    worker.return_value.run.assert_called_once_with(single_shot_query="hello")
