# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tool registry."""


from typing import Dict, List

from flagscale_agent.react.tools.base import Tool



class ToolRegistry:
    """Registry for agent tools with unified result truncation."""

    def __init__(self):
        self._tools: Dict[str, Tool] = {}

    def register(self, tool: Tool):
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool:
        if name not in self._tools:
            raise KeyError(f"Tool not found: {name}")
        return self._tools[name]

    @staticmethod
    def _missing_required(tool: Tool, kwargs: dict) -> list:
        """Required-arg names (from the tool's JSON schema) absent/empty in kwargs."""
        required = (getattr(tool, "parameters", None) or {}).get("required") or []
        return [name for name in required if kwargs.get(name) in (None, "", [], {})]

    def execute(self, tool_name: str, **kwargs) -> str:
        """Execute a tool by name, with required-arg pre-validation and
        unified result truncation.

        Missing required arguments are caught BEFORE dispatch so the model gets
        a friendly, actionable error instead of a KeyError traceback from deep
        inside the tool.
        """
        tool = self.get(tool_name)
        missing = self._missing_required(tool, kwargs)
        if missing:
            return (
                f"ERROR: required argument(s) missing for tool '{tool_name}': "
                f"{', '.join(missing)}. Re-issue the call with these arguments "
                f"(names/types per the tool schema)."
            )
        result = tool.execute(**kwargs)
        if len(result) > tool.max_result_size:
            result = result[:tool.max_result_size] + f"\n... [truncated, total {len(result)} chars]"
        return result

    def all_tools(self) -> List[Tool]:
        return list(self._tools.values())

    def to_schemas(self, fmt: str = "openai") -> List[dict]:
        if fmt == "anthropic":
            return [t.to_anthropic_schema() for t in self._tools.values()]
        return [t.to_openai_schema() for t in self._tools.values()]

    def to_schemas_filtered(self, fmt: str, tool_names: set) -> List[dict]:
        """Return schemas only for the named tools (reduces token cost)."""
        tools = [t for t in self._tools.values() if t.name in tool_names]
        if fmt == "anthropic":
            return [t.to_anthropic_schema() for t in tools]
        return [t.to_openai_schema() for t in tools]
